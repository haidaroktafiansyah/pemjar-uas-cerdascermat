Game cerdas cermat sederhana ini merupakan Final Project dari mata kuliah Pemrograman Jaringan yang diajar oleh Pak Waskitho Wibisono.

Permainan ini dibangun menggunakan bahasa pemrograman Java dan menggunakan konsep Multicast sebagai protokol komunikasi antara Server dan para Clientnya.

Cara jalankan:
- Pastikan sudah terinstall database MySQL
- Import DB lewat .sql yang sudah disediakan
- Run jalankan MulticastServer.java untuk server dan MulticastClient.java untuk client
